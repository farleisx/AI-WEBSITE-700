let users=[];
export default async function handler(req,res){
res.setHeader('Access-Control-Allow-Origin','*');
res.setHeader('Access-Control-Allow-Methods','POST,OPTIONS');
res.setHeader('Access-Control-Allow-Headers','Content-Type');
if(req.method==='OPTIONS')return res.status(200).end();
const{username,password,action}=req.body;
if(!username||!password||!action)return res.status(400).json({message:'Username,password,action required'});
if(action==='signup'){if(users.find(u=>u.username===username))return res.status(400).json({message:'User exists'});users.push({username,password});return res.status(200).json({message:'User created'});}
if(action==='signin'){const user=users.find(u=>u.username===username&&u.password===password);if(!user)return res.status(400).json({message:'Invalid credentials'});return res.status(200).json({message:'Logged in'});}
return res.status(405).json({message:'Method not allowed'});}